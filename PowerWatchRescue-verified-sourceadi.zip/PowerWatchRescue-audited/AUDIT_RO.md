# Audit tehnic al proiectului original powerwatch-offline-rescue

## Ce am verificat

Arhiva originală conține documentație, un singur proiect Android curat (`OpenPowerWatchSync`) și un singur fișier Java principal (`MainActivity.java`). Nu conține APK-ul vechi MATRIX, biblioteci binare externe, chei API, token-uri, parole sau cod de rețea.

Manifestul aplicației originale nu cere `INTERNET`. Cere doar Bluetooth/BLE și, pe Android 11 sau mai vechi, locație pentru scanarea BLE. Comenzile periculoase (`8422`, `8425`, `8430522C5E08`) apar numai în documentație, nu în codul executabil.

## Probleme găsite în prototipul original

1. **Canal BLE probabil greșit.** Codul original preferă `0013` pentru comenzi. Serviciul `...1011` este Ambiq AMDTP, unde `0011` este canalul client->server (Rx), `0012` este server->client (Tx/notify), iar `0013` este ACK/control.

2. **Captura reală confirmă rolul lui `0013`.** După scrierea brută `84 10` pe `0013`, ceasul a notificat:

   `05 00 00 20 03 37 BE 0B 4B`

   Acest pachet se decodează coerent ca AMDTP ACK: lungime `5`, tip ACK, status `03 = INVALID_PKT_LENGTH`; CRC32 pentru octetul de status `03` este exact `37 BE 0B 4B` în little-endian.

3. **Tip de scriere nepotrivit.** Capturile nRF Connect arată `WRITE NO RESPONSE` pe caracteristicile de scriere, dar prototipul original setează `WRITE_TYPE_DEFAULT`.

4. **Nu verifică ACK-ul.** Prototipul original afișează `SYNC OK` după ce termină coada locală de scrieri, chiar dacă ceasul nu a acceptat comenzile.

5. **Nu ascultă ACK pe `0013`.** Activează notificări doar pe `0012`.

6. **Framing-ul original necesită reverificare.** Constanta de 24 bytes numită `HEADER` are structura unui pachet AMDTP complet: `14 00` indică 20 bytes după prefix, iar ultimii 4 bytes (`A9 4C A7 21`) sunt exact CRC32 little-endian al celor 16 bytes anteriori. Funcția originală concatenează după acel pachet un byte de lungime plus text Base64, fără să actualizeze lungimea/CRC-ul pachetului AMDTP. Ca pachet AMDTP unic, această construcție nu corespunde formatului documentat de Ambiq.

7. **Flux incomplet față de propria documentație.** Documentația spune `query/init -> time -> config/pair values -> save -> exit`, dar aplicația originală trimite doar `time -> save -> exit`.

8. **Lipsește Gradle Wrapper.** Arhiva cere un Gradle instalat extern, deci nu este complet self-contained pentru build offline.

## Ce am schimbat în versiunea auditată

- folosesc `0011` pentru pachetele AMDTP DATA;
- ascult `0012` pentru DATA și `0013` pentru ACK/control;
- scriu cu `WRITE_TYPE_NO_RESPONSE`;
- construiesc pachetul AMDTP: lungime LE + header + payload + CRC32(payload) LE;
- cer ACK și verific statusul înainte de a continua;
- rulez mai întâi comanda inofensivă `8410`; sincronizarea nu se activează dacă testul nu primește `SUCCESS`;
- răspund cu ACK la pachetele DATA primite care îl cer;
- nu includ comenzile destructive în cod;
- nu declar succes doar pentru că scrierea locală s-a terminat.

## Limitare rămasă

Transportul AMDTP este acum implementat conform documentației Ambiq și după semnalul real primit de la ceas. Totuși, semantica exactă a payload-urilor PowerWatch `84xx` trebuie confirmată pe hardware. De aceea aplicația pornește cu un test `8410` înainte de orice schimbare a orei.

## Verificare suplimentară a transportului

Am comparat implementarea cu sursa publică AmbiqSuite `amdtp_common.c/.h`: pachetul DATA folosește lungime little-endian, header little-endian cu tipul în biții 15..12, serialul în 11..8, ACK în bitul 6 și CRC32 calculat numai peste payload. Captura reală `05 00 00 20 03 37 BE 0B 4B` se potrivește exact cu un ACK AMDTP de tip 2, status `INVALID_PKT_LENGTH` și CRC32 pentru octetul `03`.

Versiunea aceasta cere acum și un răspuns DATA la interogarea inofensivă `8410`, nu doar un ACK de transport, înainte să permită sincronizarea orei. Astfel, dacă transportul este corect dar formatul aplicației PowerWatch nu este încă cel potrivit, aplicația se oprește înainte de a scrie ora.

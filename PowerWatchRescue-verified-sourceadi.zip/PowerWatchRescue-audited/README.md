# PowerWatch Rescue — audited diagnostic build

This is a clean-room Android BLE utility derived from the public rescue prototype, with the transport layer rewritten after checking the actual Ambiq AMDTP service semantics.

## Safety behavior

The app does **not** contain or send the known destructive commands:

- `8422` factory reset / unpair
- `8425` shipmode
- `8430522C5E08` debugger lock

It has no `INTERNET` permission. It only requests Bluetooth permissions (and location on Android <= 11 because legacy Android BLE scanning requires it).

## Intended flow

1. Select the PowerWatch.
2. Run `Testează protocolul (8410)` first.
3. Only if the watch returns both an AMDTP `SUCCESS` ACK **and** an application DATA response to the harmless `8410` query does the `Sincronizează ora` button become active.
4. Sync sends `840107{UTC}{TZ}`, then `8421`, then `810F050082`, requiring successful AMDTP ACKs along the way.
5. The physical watch display remains the final source of truth.

## Important status

This audited version is intentionally a **hardware-test build**. The AMDTP transport is based on Ambiq's documented service roles and on the real ACK captured from the user's watch. The inner PowerWatch `84xx` application commands still require real-device confirmation.

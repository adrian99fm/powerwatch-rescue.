package org.openpowerwatch.sync;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.TimeZone;
import java.util.UUID;
import java.util.zip.CRC32;

/**
 * Clean-room diagnostic/rescue utility for legacy MATRIX PowerWatch devices.
 *
 * Transport implementation follows Ambiq AMDTP semantics for service ...1011:
 *   0011 = client -> watch data (write command / no response)
 *   0012 = watch -> client data (notify)
 *   0013 = ACK/control (write + notify)
 *
 * The app intentionally contains no factory-reset, shipmode, or debugger-lock command.
 */
public class MainActivity extends Activity {
    private static final UUID SERVICE_UUID = UUID.fromString("00002760-08c2-11e1-9073-0e8ac72e1011");
    private static final UUID RX_UUID = UUID.fromString("00002760-08c2-11e1-9073-0e8ac72e0011");
    private static final UUID TX_UUID = UUID.fromString("00002760-08c2-11e1-9073-0e8ac72e0012");
    private static final UUID ACK_UUID = UUID.fromString("00002760-08c2-11e1-9073-0e8ac72e0013");
    private static final UUID CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    private static final int AMDTP_TYPE_DATA = 1;
    private static final int AMDTP_TYPE_ACK = 2;
    private static final int AMDTP_ACK_BIT = 0x0040;
    private static final int AMDTP_CRC_SIZE = 4;
    private static final int MAX_AMDTP_LENGTH = 516;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private final Queue<byte[]> syncQueue = new ArrayDeque<>();
    private final Queue<String> syncLabels = new ArrayDeque<>();
    private final ByteArrayOutputStream txNotifyBuffer = new ByteArrayOutputStream();
    private final ByteArrayOutputStream ackNotifyBuffer = new ByteArrayOutputStream();

    private TextView status;
    private TextView logView;
    private Button scanButton;
    private Button testButton;
    private Button syncButton;
    private EditText macInput;

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic rxChar;
    private BluetoothGattCharacteristic txChar;
    private BluetoothGattCharacteristic ackChar;
    private BluetoothDevice selectedDevice;

    private boolean scanning;
    private boolean transportReady;
    private boolean transportVerified;
    private boolean waitingAck;
    private boolean syncRunning;
    private boolean testAckOk;
    private boolean testDataReceived;
    private int txSerial;
    private int pendingSerial = -1;
    private String pendingLabel = "";
    private int notifyStage;
    private int commandGeneration;

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice d = result.getDevice();
            if (d == null) return;
            String key = safeAddress(d) + "  " + safeName(d);
            if (!found.containsKey(key)) {
                found.put(key, d);
                log("Găsit: " + key);
            }
        }
    };

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int statusCode, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                log("Conectat. Caut serviciile BLE...");
                setStatus("Conectat");
                g.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                boolean exitWasPending = waitingAck && "EXIT".equals(pendingLabel);
                waitingAck = false;
                transportReady = false;
                if (exitWasPending) {
                    setStatus("Ieșire trimisă; verifică ceasul");
                    log("Ceasul s-a deconectat după comanda EXIT. Verifică data și ora pe ecran.");
                } else {
                    setStatus("Deconectat");
                    log("Deconectat. status=" + statusCode);
                }
                updateButtons();
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt g, int statusCode) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                fail("Căutarea serviciilor a eșuat: " + statusCode);
                return;
            }
            BluetoothGattService svc = g.getService(SERVICE_UUID);
            if (svc == null) {
                fail("Serviciul PowerWatch ...1011 nu a fost găsit");
                return;
            }
            rxChar = svc.getCharacteristic(RX_UUID);
            txChar = svc.getCharacteristic(TX_UUID);
            ackChar = svc.getCharacteristic(ACK_UUID);
            if (rxChar == null || txChar == null || ackChar == null) {
                fail("Lipsesc una sau mai multe caracteristici 0011/0012/0013");
                return;
            }
            log("0011 proprietăți=" + properties(rxChar));
            log("0012 proprietăți=" + properties(txChar));
            log("0013 proprietăți=" + properties(ackChar));
            notifyStage = 0;
            enableNextNotification();
        }

        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int statusCode) {
            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                fail("Activarea notificărilor a eșuat: " + statusCode);
                return;
            }
            notifyStage++;
            enableNextNotification();
        }

        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            byte[] value = characteristic.getValue();
            if (value == null) value = new byte[0];
            handleNotification(characteristic.getUuid(), value);
        }

        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic characteristic, int statusCode) {
            // WRITE_TYPE_NO_RESPONSE does not require this callback, but some stacks still emit it.
            log("Write callback " + shortUuid(characteristic.getUuid()) + " status=" + statusCode);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        BluetoothManager bm = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        adapter = bm == null ? null : bm.getAdapter();
        buildUi();
        requestNeededPermissions();
        setStatus("Pregătit");
        updateButtons();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (gatt != null) {
            try { gatt.close(); } catch (Exception ignored) { }
            gatt = null;
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("PowerWatch Rescue");
        title.setTextSize(24);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("BLE local, fără cloud. Întâi testează protocolul, apoi sincronizează ora.");
        root.addView(sub);

        macInput = new EditText(this);
        macInput.setHint("MAC opțional (AA:BB:CC:DD:EE:FF)");
        macInput.setSingleLine(true);
        macInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        macInput.setText(getPrefs().getString("last_mac", ""));
        root.addView(macInput);

        scanButton = new Button(this);
        scanButton.setText("Caută / alege ceasul");
        scanButton.setOnClickListener(v -> startScanAndChoose());
        root.addView(scanButton);

        testButton = new Button(this);
        testButton.setText("Testează protocolul (8410)");
        testButton.setOnClickListener(v -> connectFor(false));
        root.addView(testButton);

        syncButton = new Button(this);
        syncButton.setText("Sincronizează ora");
        syncButton.setOnClickListener(v -> connectFor(true));
        root.addView(syncButton);

        status = new TextView(this);
        status.setTextSize(18);
        root.addView(status);

        logView = new TextView(this);
        logView.setTextSize(12);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(logView);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private SharedPreferences getPrefs() {
        return getSharedPreferences("settings", MODE_PRIVATE);
    }

    private void setStatus(String s) {
        handler.post(() -> status.setText("Status: " + s));
    }

    private void log(String s) {
        handler.post(() -> logView.append(String.format(Locale.US, "%tT  %s\n", new Date(), s)));
    }

    private void fail(String msg) {
        waitingAck = false;
        syncRunning = false;
        syncQueue.clear();
        syncLabels.clear();
        setStatus("EROARE");
        log("EROARE: " + msg);
        updateButtons();
    }

    private void updateButtons() {
        handler.post(() -> {
            boolean perms = hasPermissions();
            scanButton.setEnabled(perms && !syncRunning);
            testButton.setEnabled(perms && !syncRunning);
            // Sync is deliberately gated behind a successful harmless 8410 transport ACK.
            syncButton.setEnabled(perms && transportVerified && !syncRunning);
        });
    }

    @SuppressLint("MissingPermission")
    private void startScanAndChoose() {
        if (!hasPermissions()) { requestNeededPermissions(); return; }
        if (adapter == null || !adapter.isEnabled()) { fail("Bluetooth este oprit"); return; }
        found.clear();
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { fail("Scanner BLE indisponibil"); return; }
        setStatus("Caut...");
        log("Scanare BLE 8 secunde...");
        scanning = true;
        scanner.startScan(scanCallback);
        handler.postDelayed(() -> {
            if (!scanning) return;
            scanning = false;
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) { }
            showDeviceChooser();
        }, 8000);
    }

    @SuppressLint("MissingPermission")
    private void showDeviceChooser() {
        if (found.isEmpty()) { fail("Niciun dispozitiv BLE găsit. Poți introduce MAC manual."); return; }
        List<String> keys = new ArrayList<>(found.keySet());
        ArrayAdapter<String> arr = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, keys);
        new AlertDialog.Builder(this)
                .setTitle("Alege PowerWatch")
                .setAdapter(arr, (d, which) -> {
                    selectedDevice = found.get(keys.get(which));
                    transportVerified = false;
                    macInput.setText(safeAddress(selectedDevice));
                    getPrefs().edit().putString("last_mac", safeAddress(selectedDevice)).apply();
                    log("Selectat: " + keys.get(which));
                    setStatus("Selectat");
                })
                .show();
    }

    @SuppressLint("MissingPermission")
    private void connectFor(boolean requestSync) {
        if (!hasPermissions()) { requestNeededPermissions(); return; }
        if (adapter == null || !adapter.isEnabled()) { fail("Bluetooth este oprit"); return; }

        String mac = macInput.getText().toString().trim();
        try {
            if (selectedDevice == null && !mac.isEmpty()) selectedDevice = adapter.getRemoteDevice(mac);
        } catch (IllegalArgumentException e) {
            fail("Adresă MAC invalidă");
            return;
        }
        if (selectedDevice == null) { fail("Alege ceasul sau introdu MAC-ul"); return; }
        getPrefs().edit().putString("last_mac", safeAddress(selectedDevice)).apply();

        if (requestSync && !transportVerified) {
            fail("Rulează mai întâi testul 8410");
            return;
        }

        commandGeneration++;
        waitingAck = false;
        transportReady = false;
        syncRunning = requestSync;
        testAckOk = false;
        testDataReceived = false;
        syncQueue.clear();
        syncLabels.clear();
        txNotifyBuffer.reset();
        ackNotifyBuffer.reset();
        txSerial = 0;

        if (requestSync) {
            syncQueue.add(timePayload()); syncLabels.add("TIME");
            syncQueue.add(new byte[] {(byte) 0x84, 0x21}); syncLabels.add("SAVE");
            syncQueue.add(new byte[] {(byte) 0x81, 0x0F, 0x05, 0x00, (byte) 0x82}); syncLabels.add("EXIT");
        } else {
            syncQueue.add(new byte[] {(byte) 0x84, 0x10}); syncLabels.add("TEST");
        }

        if (gatt != null) {
            try { gatt.close(); } catch (Exception ignored) { }
            gatt = null;
        }
        setStatus("Conectare...");
        log("Conectare la " + safeAddress(selectedDevice));
        gatt = selectedDevice.connectGatt(this, false, gattCallback);
        updateButtons();
    }

    @SuppressLint("MissingPermission")
    private void enableNextNotification() {
        if (gatt == null) return;
        BluetoothGattCharacteristic c;
        if (notifyStage == 0) c = txChar;
        else if (notifyStage == 1) c = ackChar;
        else {
            transportReady = true;
            setStatus("Transport pregătit");
            log("Notificări active pe 0012 și 0013.");
            handler.postDelayed(this::sendNextCommand, 120);
            return;
        }

        boolean local = gatt.setCharacteristicNotification(c, true);
        log("Notify " + shortUuid(c.getUuid()) + " local=" + local);
        if (!local) { fail("Nu pot activa notificările pe " + shortUuid(c.getUuid())); return; }
        BluetoothGattDescriptor d = c.getDescriptor(CCCD_UUID);
        if (d == null) { fail("CCCD lipsește pe " + shortUuid(c.getUuid())); return; }
        d.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        if (!gatt.writeDescriptor(d)) fail("writeDescriptor a returnat false");
    }

    private void sendNextCommand() {
        if (!transportReady || waitingAck || gatt == null || rxChar == null) return;
        byte[] raw = syncQueue.poll();
        String label = syncLabels.poll();
        if (raw == null || label == null) {
            if (syncRunning) {
                syncRunning = false;
                setStatus("Comenzi confirmate; verifică ceasul");
                log("TIME + SAVE + EXIT au primit ACK. Verifică fizic data și ora.");
            }
            updateButtons();
            return;
        }

        pendingSerial = txSerial & 0x0F;
        pendingLabel = label;
        byte[] packet = buildDataPacket(raw, pendingSerial, true);
        log("TX " + label + " raw=" + hex(raw));
        log("TX AMDTP sn=" + pendingSerial + " " + hex(packet));
        waitingAck = true;
        int generation = ++commandGeneration;
        if (!writeNoResponse(rxChar, packet)) {
            waitingAck = false;
            fail("Scrierea pe 0011 a eșuat");
            return;
        }
        handler.postDelayed(() -> {
            if (waitingAck && generation == commandGeneration) {
                fail("Timeout ACK pentru " + pendingLabel + " (0013)");
            }
        }, 3500);
    }

    @SuppressLint("MissingPermission")
    private boolean writeNoResponse(BluetoothGattCharacteristic c, byte[] value) {
        if (gatt == null || c == null) return false;
        c.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
        c.setValue(value);
        return gatt.writeCharacteristic(c);
    }

    private void handleNotification(UUID uuid, byte[] value) {
        log("RX " + shortUuid(uuid) + " " + hex(value));
        if (ACK_UUID.equals(uuid)) {
            appendAndParse(ackNotifyBuffer, value, true);
        } else if (TX_UUID.equals(uuid)) {
            appendAndParse(txNotifyBuffer, value, false);
        }
    }

    private void appendAndParse(ByteArrayOutputStream buffer, byte[] value, boolean ackChannel) {
        buffer.write(value, 0, value.length);
        while (true) {
            byte[] all = buffer.toByteArray();
            if (all.length < 2) return;
            int len = u16le(all, 0);
            if (len < AMDTP_CRC_SIZE || len > MAX_AMDTP_LENGTH) {
                log("AMDTP lungime invalidă pe " + (ackChannel ? "0013" : "0012") + ": " + len);
                buffer.reset();
                return;
            }
            int total = 4 + len;
            if (all.length < total) return;
            byte[] packet = new byte[total];
            System.arraycopy(all, 0, packet, 0, total);
            buffer.reset();
            if (all.length > total) buffer.write(all, total, all.length - total);
            parseAmdtpPacket(packet, ackChannel);
        }
    }

    private void parseAmdtpPacket(byte[] packet, boolean ackChannel) {
        int len = u16le(packet, 0);
        int header = u16le(packet, 2);
        int type = (header >>> 12) & 0x0F;
        int serial = (header >>> 8) & 0x0F;
        boolean ackRequested = (header & AMDTP_ACK_BIT) != 0;
        int dataLen = len - AMDTP_CRC_SIZE;
        byte[] data = new byte[dataLen];
        System.arraycopy(packet, 4, data, 0, dataLen);
        long expectedCrc = u32le(packet, 4 + dataLen);
        long actualCrc = crc32(data);
        if (expectedCrc != actualCrc) {
            log("AMDTP CRC greșit: primit=" + hex32(expectedCrc) + " calculat=" + hex32(actualCrc));
            return;
        }

        if (type == AMDTP_TYPE_ACK) {
            if (dataLen < 1) { log("ACK fără status"); return; }
            int code = data[0] & 0xFF;
            log("ACK sn=" + serial + " status=" + code + " (" + statusName(code) + ")");
            if (waitingAck && serial == pendingSerial) {
                commandGeneration++;
                waitingAck = false;
                if (code != 0) {
                    fail("Ceasul a respins " + pendingLabel + ": " + statusName(code));
                    return;
                }
                txSerial = (txSerial + 1) & 0x0F;
                if ("TEST".equals(pendingLabel)) {
                    testAckOk = true;
                    log("Testul 8410 a primit ACK AMDTP_STATUS_SUCCESS; aștept și răspuns DATA pe 0012.");
                    maybeFinishTest();
                    final int testGen = commandGeneration;
                    handler.postDelayed(() -> {
                        if (!transportVerified && testAckOk && !testDataReceived && testGen == commandGeneration) {
                            fail("8410 a primit ACK, dar nu a venit răspuns DATA pe 0012. Payload-ul PowerWatch poate necesita altă încadrare.");
                        }
                    }, 2500);
                    return;
                }
                if ("EXIT".equals(pendingLabel)) {
                    syncRunning = false;
                    setStatus("Sincronizare trimisă; verifică ceasul");
                    log("EXIT confirmat. Verifică fizic data și ora.");
                    updateButtons();
                    handler.postDelayed(() -> { if (gatt != null) gatt.disconnect(); }, 1200);
                    return;
                }
                handler.postDelayed(this::sendNextCommand, 120);
            }
            return;
        }

        if (type == AMDTP_TYPE_DATA) {
            log("DATA sn=" + serial + " ack=" + ackRequested + " payload=" + hex(data));
            if (ackRequested) sendAck(serial, 0);
            if ("TEST".equals(pendingLabel) && dataLen > 0) {
                testDataReceived = true;
                log("Răspuns DATA primit pentru testul 8410.");
                maybeFinishTest();
            }
            return;
        }

        log("AMDTP tip=" + type + " sn=" + serial + " payload=" + hex(data));
    }

    private void maybeFinishTest() {
        if (!testAckOk || !testDataReceived) return;
        commandGeneration++;
        transportVerified = true;
        syncRunning = false;
        setStatus("Protocol + răspuns 8410 OK — poți sincroniza");
        log("Test complet: ACK SUCCESS + răspuns DATA de la ceas.");
        updateButtons();
    }

    private void sendAck(int serial, int statusCode) {
        if (ackChar == null || gatt == null) return;
        byte[] packet = buildAckPacket(serial, statusCode);
        log("TX ACK sn=" + serial + " status=" + statusCode + " " + hex(packet));
        if (!writeNoResponse(ackChar, packet)) log("AVERTISMENT: nu am putut scrie ACK pe 0013");
    }

    private static byte[] buildDataPacket(byte[] payload, int serial, boolean requestAck) {
        int len = payload.length + AMDTP_CRC_SIZE;
        int header = (AMDTP_TYPE_DATA << 12) | ((serial & 0x0F) << 8) | (requestAck ? AMDTP_ACK_BIT : 0);
        byte[] out = new byte[4 + len];
        put16le(out, 0, len);
        put16le(out, 2, header);
        System.arraycopy(payload, 0, out, 4, payload.length);
        put32le(out, 4 + payload.length, crc32(payload));
        return out;
    }

    private static byte[] buildAckPacket(int serial, int statusCode) {
        byte[] status = new byte[] {(byte) statusCode};
        int len = 1 + AMDTP_CRC_SIZE;
        int header = (AMDTP_TYPE_ACK << 12) | ((serial & 0x0F) << 8);
        byte[] out = new byte[9];
        put16le(out, 0, len);
        put16le(out, 2, header);
        out[4] = status[0];
        put32le(out, 5, crc32(status));
        return out;
    }

    private static byte[] timePayload() {
        long nowMs = System.currentTimeMillis();
        long utc = nowMs / 1000L;
        int offsetMin = TimeZone.getDefault().getOffset(nowMs) / 60000;
        return new byte[] {
                (byte) 0x84, 0x01, 0x07,
                (byte) ((utc >>> 24) & 0xFF),
                (byte) ((utc >>> 16) & 0xFF),
                (byte) ((utc >>> 8) & 0xFF),
                (byte) (utc & 0xFF),
                (byte) ((offsetMin >> 8) & 0xFF),
                (byte) (offsetMin & 0xFF)
        };
    }

    private static long crc32(byte[] data) {
        CRC32 crc = new CRC32();
        crc.update(data, 0, data.length);
        return crc.getValue() & 0xFFFFFFFFL;
    }

    private static int u16le(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8);
    }

    private static long u32le(byte[] b, int off) {
        return ((long) b[off] & 0xFF)
                | (((long) b[off + 1] & 0xFF) << 8)
                | (((long) b[off + 2] & 0xFF) << 16)
                | (((long) b[off + 3] & 0xFF) << 24);
    }

    private static void put16le(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xFF);
        b[off + 1] = (byte) ((v >>> 8) & 0xFF);
    }

    private static void put32le(byte[] b, int off, long v) {
        b[off] = (byte) (v & 0xFF);
        b[off + 1] = (byte) ((v >>> 8) & 0xFF);
        b[off + 2] = (byte) ((v >>> 16) & 0xFF);
        b[off + 3] = (byte) ((v >>> 24) & 0xFF);
    }

    private static String statusName(int code) {
        switch (code) {
            case 0: return "SUCCESS";
            case 1: return "CRC_ERROR";
            case 2: return "INVALID_METADATA_INFO";
            case 3: return "INVALID_PKT_LENGTH";
            case 4: return "INSUFFICIENT_BUFFER";
            case 5: return "UNKNOWN_ERROR";
            case 6: return "BUSY";
            case 7: return "NOTIFY_DISABLED";
            case 8: return "TX_NOT_READY";
            case 9: return "RESEND_REPLY";
            case 10: return "RECEIVE_CONTINUE";
            case 11: return "RECEIVE_DONE";
            default: return "STATUS_" + code;
        }
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNeededPermissions() {
        if (hasPermissions()) return;
        if (Build.VERSION.SDK_INT >= 31) {
            requestPermissions(new String[] {Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, 42);
        } else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, 42);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        updateButtons();
    }

    @SuppressLint("MissingPermission")
    private static String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null ? "(fără nume)" : n;
        } catch (SecurityException e) {
            return "(nume ascuns)";
        }
    }

    @SuppressLint("MissingPermission")
    private static String safeAddress(BluetoothDevice d) {
        try { return d.getAddress(); }
        catch (SecurityException e) { return ""; }
    }

    private static String properties(BluetoothGattCharacteristic c) {
        int p = c.getProperties();
        List<String> s = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) s.add("WRITE_NO_RESPONSE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) s.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) s.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) s.add("INDICATE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) s.add("READ");
        return s.toString();
    }

    private static String shortUuid(UUID u) {
        String s = u.toString();
        return s.substring(0, 8) + "..." + s.substring(s.length() - 4);
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(String.format(Locale.US, "%02X", x & 0xFF));
        }
        return sb.toString();
    }

    private static String hex32(long v) {
        return String.format(Locale.US, "%08X", v & 0xFFFFFFFFL);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
